# Start MongoDB
sudo service mongod start