# Deploy Contract
python3 scripts/deploy_contract.py

# Interact with Contract
python3 scripts/interact_contract.py