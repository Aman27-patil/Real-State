# Ensure Flask and MongoDB are running
flask run