cd frontend
npm install
npm start