# Ensure your virtual environment is activated
pytest tests/